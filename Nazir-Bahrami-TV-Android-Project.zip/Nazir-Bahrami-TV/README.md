# NAZIR BAHRAMI TV 4K

Android starter project for phones and Android TV. Includes channel search, manual channel entry, and M3U playlist import.

## Build APK
1. Upload this folder's contents to a new GitHub repository.
2. Open **Actions**.
3. Select **Build Nazir Bahrami TV APK**.
4. Press **Run workflow** (or push to `main`).
5. Open the completed workflow run and download the `Nazir-Bahrami-TV-APK` artifact.

## Important
- This is a starter app, not a satellite receiver.
- It does not include paid or unauthorized channel streams.
- Add legal stream URLs or an M3U playlist you have permission to use.
- Direct satellite reception requires compatible tuner/receiver hardware.
- Playback depends on the device's installed media handlers and supported stream format.
