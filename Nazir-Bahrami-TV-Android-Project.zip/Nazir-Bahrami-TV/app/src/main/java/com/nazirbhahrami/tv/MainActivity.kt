package com.nazirbhahrami.tv

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import android.graphics.Color
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private val navy = Color.rgb(5, 16, 45)
    private val gold = Color.rgb(245, 185, 35)
    private lateinit var list: LinearLayout
    private val channels = mutableListOf<Pair<String, String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(navy)
        }
        val title = TextView(this).apply {
            text = "👑  NAZIR BAHRAMI TV 4K"
            textSize = 25f; setTextColor(gold); gravity = Gravity.CENTER
            setPadding(8, 14, 8, 14)
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "LIVE TV  •  MOVIES  •  SPORTS  •  NEWS"
            textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(4, 4, 4, 18)
        }
        root.addView(subtitle)

        val search = EditText(this).apply {
            hint = "جستجوی نام کانال..."
            setSingleLine(true); textSize = 16f
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(14, 10, 14, 10)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2))
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val add = Button(this).apply { text = "افزودن کانال" }
        val playlist = Button(this).apply { text = "بارگذاری M3U" }
        buttons.addView(add, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(playlist, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val note = TextView(this).apply {
            text = "برای تماشای شبکه‌ها، لینک پخش مجاز یا فهرست M3U خود را اضافه کنید."
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
            setPadding(4, 12, 4, 4)
        }
        root.addView(note)
        setContentView(root)

        add.setOnClickListener { addChannelDialog() }
        playlist.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply { type = "*/*" }
            startActivityForResult(intent, 44)
        }
        search.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { render(s.toString()) }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        render("")
    }

    private fun addChannelDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 8, 20, 0) }
        val name = EditText(this).apply { hint = "نام کانال" }
        val url = EditText(this).apply { hint = "لینک پخش (https://...)" }
        box.addView(name); box.addView(url)
        AlertDialog.Builder(this).setTitle("افزودن کانال")
            .setView(box).setPositiveButton("ذخیره") { _, _ ->
                val n = name.text.toString().trim()
                val u = url.text.toString().trim()
                if (n.isNotEmpty() && (u.startsWith("https://") || u.startsWith("http://"))) {
                    channels.add(n to u); render("")
                } else Toast.makeText(this, "نام و لینک معتبر وارد کنید", Toast.LENGTH_LONG).show()
            }.setNegativeButton("لغو", null).show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 44 && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openInputStream(data.data!!)?.bufferedReader()?.useLines { lines ->
                    var name = "کانال تازه"
                    lines.forEach { line ->
                        when {
                            line.startsWith("#EXTINF", true) -> name = line.substringAfterLast(",").trim().ifEmpty { "کانال تازه" }
                            line.startsWith("http", true) -> { channels.add(name to line.trim()); name = "کانال تازه" }
                        }
                    }
                }
                render("")
                Toast.makeText(this, "فهرست بارگذاری شد", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(this, "خواندن فایل ممکن نشد", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun render(query: String) {
        list.removeAllViews()
        val filtered = channels.filter { it.first.contains(query, true) }
        if (filtered.isEmpty()) {
            val empty = TextView(this).apply {
                text = if (channels.isEmpty()) "هنوز کانالی اضافه نشده است. از «افزودن کانال» یا «بارگذاری M3U» استفاده کنید."
                       else "کانالی پیدا نشد."
                setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
                setPadding(20, 45, 20, 45)
            }
            list.addView(empty); return
        }
        filtered.forEach { channel ->
            val row = Button(this).apply {
                text = "▶   ${channel.first}"
                textSize = 16f; setTextColor(gold)
                setOnClickListener {
                    try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(channel.second))) }
                    catch (_: Exception) { Toast.makeText(this@MainActivity, "پخش‌کننده‌ای برای این لینک پیدا نشد", Toast.LENGTH_LONG).show() }
                }
            }
            list.addView(row, ViewGroup.LayoutParams(-1, -2))
        }
    }
}
